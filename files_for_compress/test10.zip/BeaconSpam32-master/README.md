# BeaconSpam32

Created from Spacehuhn's esp8266 beaconspam program (https://github.com/spacehuhn/esp8266_beaconSpam).

Ported to work on the ESP32 along with OLED and button support.

Required Arduino libraries: 

- SSD1306 OLED display library (https://github.com/ThingPulse/esp8266-oled-ssd1306)

- ESP32 board files (add https://dl.espressif.com/dl/package_esp32_index.json in board manager)

## Todos

- Check overall performance / memory usage

- ~~Look into using FreeRTOS' xTaskCreate for loop / allocate certain tasks to certain cores~~
	no need to! By default, Arduino's loop() runs on core 1, while networking stack and protocols run on core 0 (source: https://www.hackster.io/rayburne/esp32-in-love-with-both-cores-8dd948)

- Check usage of current API as it also creates an ESP-Bxxx network, probably down to default wifi configuration initialization
